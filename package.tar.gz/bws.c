/*Branching Wiener Sausage - see readme for details and /scripts for compilation and execution notes*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#if defined linux || defined __APPLE__
#include <unistd.h>
#endif
#include "lattice_core.h"
#include "bws.h"

//we have predetermined write times at 1,2,3,...9,10,20,....90,100,200,.....900,1000,2000,...
#define INIT_WRITE_TIMES {int i=0; int a =0; int b=0; for(a =0; a < TIME_WRITE_SCALES; a++){for (b = 1; b <= TIME_WRITE_COUNTS; b++){ write_times[i++] = (b)*pow(10,a); }}}
//moments for just the trace (todo add others) we note that MAX_MOMENTS does not incude the zero'th moment so we add MAX_MOMENTS+1 - this is just a convention
#define INIT_MOMENTS_TRACE {int t; int m; for(m = 0; m <= MAX_MOMENTS; m++){for(t = 0; t < MAX_T; t++){trace_moments[t][m]=0;}}; INIT_WRITE_TIMES; }
//prepare an array to store a histogram of for trace counts i each sample path - it is assumed to be between 1 and L^2 for practicality - check?
#define INIT_TRACE_HISTOGRAM(L) {int l; for (l=0;l< L*L; l++ ){__trace_histogram[l]=0;}}
//write each recorded obs(t) - in this case just one - extend with an offset for other moments e.g. 1-8 for trace, 1-8 for population count
#define WRITE_MOMENTS_TRACE(x,t) {int i; for(i = 0; i <= MAX_MOMENTS; i++){trace_moments[t][i] += (long double)pow(x,i);}}
//write the header for the tabular data - make sure it matches what is in COMMIT_MOMENTS_TRACE
#define WRITE_HEADER {int i;printf("chunk\tL\tD\tBCs\tt"); for(i = 0; i <= MAX_MOMENTS; i++){printf("\tM%d",i);} printf("\n");}
//flush out moments to standard out - add some header info that will be used in tabular data handling
#define COMMIT_MOMENTS_TRACE(c,L,D,BCs){ int t; int m; for(t = 0; t < MAX_T; t++){printf("%d\t%d\t%d\t%d\t%ld",c,L,D,BCs,write_times[t]); for(m = 0; m <= MAX_MOMENTS; m++){printf("\t%.1Lf", trace_moments[t][m]);} printf("\n");}; } INIT_MOMENTS_TRACE
//trace=t, always at least 1 and at most volume of lattice but going to assume far less in higher dimensions
#define BIN_TRACE(t) {__trace_histogram[t-1]++;}
//flush out the histogram in a comment
#define WRITE_TRACE_HIST(L) {printf("#TRACE_HIST_L=%d; ",L); int l; for(l=0;l<L*L; l++){printf("%d ", __trace_histogram[l]); } printf("\n");}

#define _RANDOM_INT(r, n)unsigned x= genrand_int32(); while (x >= RNG_MT_MAX - (RNG_MT_MAX % n)) {x = genrand_int32();} x %= n; r = (int)x;
#define RANDOM_DOUBLE  genrand_real1()
#define RANDOM_ORIENTATION (genrand_int32() % (2*D))
#define POP_RANDOM_PARTICLE(p)int r,top; _RANDOM_INT(r, stack.top); p = stack.stk[r]; stack.stk[r] = POP(top); p;
#define EXP_WAIT(n) (1.0/(double)n) * (-log(1-RANDOM_DOUBLE))

#define POP(p)  p=stack.stk[--stack.top]; p
#define PUSH(p) stack.stk[stack.top++] = p;
#define PARTICLE_COUNT stack.top
#define ADD(p) if(TRACE_FLAG!=(lattice[p] & TRACE_FLAG))__trace++; lattice[p] |= ADD_FLAG; PUSH(p); //push(&stack,u);
#define REMOVE(p) lattice[p] ^= CURRENT_FLAG
#define MOVE(from,to) REMOVE(from); ADD(to);
#define STAY(p) ADD(p)
#define TRY_ADD_IMMOBILE(p)  if(IMMOBILE_FLAG!=(lattice[p] & IMMOBILE_FLAG))__immobileTrace++ ;lattice[p] |= IMMOBILE_FLAG

/*globals*/
char *lattice;
SSTACK stack;
long double trace_moments[MAX_T][MAX_MOMENTS + 1];//NB: adding 1 to number of moments to capture 0th moment!! ALL FOREACH shoud terminate at <=MAX_MOMENTS
long write_times[MAX_T];
int __trace = 0, __immobileTrace = 0, __maxParticles=0;
int *__trace_histogram;
double __avalanche = 0;
int sizeCount = 0;
// Avalanche (Avalanche statistics is highly not optimised, don't take it serious yet)
long double avalanche_moments[10][MAX_MOMENTS + 1]; // Here, I'm assuming that there will be 10 different system sizes to be checked!


int main(int argc, char *argv[])
{
	// Set buffer to zero so that process has to write into stdout immediately
	setlinebuf(stdout);
	double sigma = 0.0, h = 0.95;
	sigma = (1 - h) / 2;
	int BCs, D,l,Ln,N,seed;
	parse_args(&BCs, &D, &Ln, &N, &seed, argc, argv);
	int L = pow(2, Ln);
	__trace_histogram = malloc((L * L * sizeof(int)));
	printf("#Parameters: (Seed) %i, (Hopping rate) %g, (Realisations) %i, \
	(Chunk size) %i, (Dimension) %i, (Maximum Lattice size) %g \n", seed, h, N, CHUNKS_SIZE, D, pow(2,Ln) );
	init_genrand(seed);
	allocate_lattice(&lattice, L, D);
	WRITE_HEADER;
	for (l = 4; l <= Ln; l++){
		L = pow(2, l) - 1;
		printf("# Running for L = %i\n", L);
		run_for_realisations(N, L, D, h, sigma, BCs);
		sizeCount++; // This indexes avalanche moments
	}
}

inline void run_for_realisations(int N, int L, int D, double h, double sigma, int bcs) {
	INIT_MOMENTS_TRACE;
	INIT_TRACE_HISTOGRAM(L);
	
	// Raw avalanche
	int l, m;
	for(m = 0; m <= MAX_MOMENTS; m++){
		for(l = 0; l < 10; l++){
			avalanche_moments[l][m]=0;
		}
	}
	// make this block a macro
	
 	int _n = 0, chunk = 0;
	for (_n = 0; _n < N; _n++) {
		double rd = 0.0;
		long double time = 0.0;
		int write_time_index = 0, pos = 0, ro = 0, next = 0;
		init_lattice(bcs, L, D); stack.top = 0; __trace = 0; __immobileTrace = 0, __maxParticles =0; __avalanche = 0.0;

		ADD(get_center(L, D));
		do {
			time += (EXP_WAIT(PARTICLE_COUNT));

			__avalanche += time * ((double) PARTICLE_COUNT);

			if (write_times[MAX_T - 1] < time) { break; }//todo see why this sometimes happens

			POP_RANDOM_PARTICLE(pos);
			rd = RANDOM_DOUBLE;//to choose sub-process...

			if (rd <= sigma) {//branch locally (and stay)
				STAY(pos);
				ADD(pos);
			}
			else if (rd <= sigma + h) { //hop
				ro = RANDOM_ORIENTATION;
				next = diffuse(pos, ro);
				if (next == -1) {//-1 illegal - dead for open boundary - not put back on stack, reset flag on lattice
					REMOVE(pos);
					continue;
				}
				MOVE(pos, next);
			}
			else {//extinction
				REMOVE(pos);
				continue;
			}

			//inefficient but we are checking - todo: update moments to use offsets (increase capcity by MAX_MOMENTS+1) and WRITE_MOMENTS(__trace, __maxParticles,write_time_index)
			//if (PARTICLE_COUNT > __maxParticles)__maxParticles = PARTICLE_COUNT;
			//when time advances, write out all the values for each time in interval since last write. actual times are indexed
			while (write_times[write_time_index] < time) {WRITE_MOMENTS_TRACE(__trace, write_time_index);write_time_index++;}
		} while (PARTICLE_COUNT);
		//fill in the gaps
		while (write_time_index < MAX_T) {WRITE_MOMENTS_TRACE(__trace, write_time_index);write_time_index++;}
		BIN_TRACE(__trace);
		//choose N = K*CHUNK_SIZE + 1
		if ((_n+1) % CHUNKS_SIZE == 0 || (_n+1) == N) {chunk++; COMMIT_MOMENTS_TRACE(chunk, L, D, bcs);	}
		
		// Raw avalanche
		int i;
		long double normalised_avalanche = __avalanche / ((double) N); 
		/* This is such that numbers don't explode. Else, they go with N^n. Rather cut them into pieces here, and then blow them up later */
		for(i = 0; i <= MAX_MOMENTS; i++){
				avalanche_moments[sizeCount][i] += (long double)pow(normalised_avalanche,i);
		} // At the end of each run in system size L write the final avalanche size into avalanche_moments.

	}
	WRITE_TRACE_HIST(L);
	
	//Write out avalanches
	printf("#AVALCOMMENT below are avalanche moment <s^n>. However, read <s^n> = <s^0>^n*<s^n>! Moments have to be inflated by N^n.\n");
	printf("#AVALANCHES %i ", L);
	int i;
	for(i = 0; i <= MAX_MOMENTS; i++){
		printf("\t%.1Lf", avalanche_moments[sizeCount][i]);
	}
	printf("\n");
	
	
}

//todo: check distribution of sub-processes, check linux compile, profiling, divide moments


int parse_args(int *bcs, int *D, int *Ln, int *N, int *seed, int argc, char *argv[]);
int parse_args(int *bcs, int *D, int *Ln, int *N, int *seed, int argc, char *argv[]) {
// Define default parameters
*seed = 5; *N = 1000000; *D = 2; *Ln = 9; *bcs = 0;
// Check if Windows. Then get parameters as "seed, N, Ln (lattice length), D, bcs"
#ifdef _WIN64
	int temp = time(NULL);
	if (argc > 1 && atoi(argv[1]) != -1)
		temp = atoi(argv[1]);
	if (argc == 3) {
		*seed = temp; *N = atoi(argv[2]);
	}

	else if (argc == 6) {
		*seed = temp; *N = atoi(argv[2]); *Ln = atoi(argv[3]); *D = atoi(argv[4]); *bcs = atoi(argv[5]);
	}
	else {
		printf("#Using default arguments - pass either seed and N or all args (seed,N, Ln, D, Bcs)\n");
	}
#endif

// Check for linux, if so use getopt
#if defined linux || defined __APPLE__
int ch;
while ((ch = getopt(argc, argv, "S:N:L:D:B:h")) != -1)  // bw change 'R'
	switch (ch) {
	case 'S':// seed
		*seed = atof(optarg);
		break;
	case 'N'://realisations
		*N = atoi(optarg);
		break;
	case 'L':
		*Ln = atoi(optarg);
		break;
  case 'D'://dimensions
		*D = atoi(optarg);
		break;
	case 'B':
		*bcs= atoi(optarg);
		break;
	case 'h':
		printhelp();
		_exit(0);
	default:
		break;
	}

#endif
	return 1;
}

void printhelp(){
printf("Simulation of a Branching Wiener Sausage at Critical Point \n\
	Correct syntax (UNIX-only): ./bws -S (Seed) -N (#Realisations) -L (L <= 2^input) -D (dim) -B (Boundary-conditions as bitmask) -h [help]\n ");
}
