gcc bws.c lattice_core.c ./rng/mt19937ar_clean_bkp.c -lm -O3 -o bws
