//#basic bosonic L^D lattice
#include "lattice_core.h"
#include <stdlib.h>
#include <stdio.h>

int _D = 0, _L = 0, _volume = 0, _BCS = 0;

char* lattice;
int lattice_actions[20];
int dimension_increment_maps[20];
int wrap_increment_maps[20];

#define FALSE 0
#define TRUE 1
#define BOUNDARY_FLAG(d) (1<<d)
#define IS_BOUNDARY_CLOSED(d,flag) (BOUNDARY_FLAG(d) == (flag & BOUNDARY_FLAG(d)))
#define IS_ALLOWED_TRANSITION(i,inext,dim_scale) (PARTITION_OF(i, dim_scale*_L) == PARTITION_OF(inext, dim_scale*_L))
#define PARTITION_OF(i,j) (int)( floor(i/((double)j)))

void __init(int L, int D) {
	_L = L; _D = D;
	_volume = (int)pow(_L, D);
}

int allocate_lattice(char **buffer, int L, int D) {
	__init(L, D);
	char* myBuf = (char*)*buffer;
	int size = _volume * sizeof(char);
	lattice = myBuf = (char*)malloc(size);
	if (*buffer == NULL)
	{
		printf("\nERROR: Memory allocation did not complete successfully! Required size %i bytes", size);
	}
	return 0;
}

void init_lattice(int boundary_conditions, int L, int D)
{
	_BCS = boundary_conditions;

	__init(L, D); int i = 0;
	for (i = 0;i < _volume;i++) {
		lattice[i] = 0;
	}

	int choice;
	for (choice = 0; choice < 2 * D; choice++) {
		int dim = (int)floor(choice / 2);
		int sign = 1; if (choice % 2 == 0)sign = -1;
		//these could be computed once and added to a list
		int j = (int)pow(L, dim); //the jump for moving around the lattice structure e.g. 1, L, L^2 etc. see hier. pend.
		dimension_increment_maps[choice] = j;
		lattice_actions[choice] = sign * j;
		wrap_increment_maps[choice] = (-1 * sign) * (j*L-j);
	}
	//mark bit for boundary - todo
	//check BC for closed boundaries
}

int diffuse(int pos, int choice) {
	int pos_next = pos + lattice_actions[choice];
	int d_scale = dimension_increment_maps[choice];
	if (IS_ALLOWED_TRANSITION(pos, pos_next, d_scale))
		return pos_next;
	if (IS_BOUNDARY_CLOSED(choice, _BCS) == TRUE) {
		//return pos;//reflecting
		return pos + wrap_increment_maps[choice];//wrap?
	}
	//if we are wrapping?
	return -1;
}

int get_center(int L,int D) {
	__init(L, D);
	int bisectAt = round(L / 2);
	int center = 0, i = 0;
	for (i = 0; i < _D; i++) {
		center += (bisectAt * (int)(pow(L, i)));
	}
	return center;
}
