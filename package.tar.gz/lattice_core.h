#pragma once

#include <math.h>


int diffuse(int pos, int choice);
void init_lattice(int boundary_conditions, int L, int D);
int allocate_lattice(char** buffer, int L, int D);
int get_center(int L, int D);